/**
 * Proxy Service Worker alias (sw.js -> service-worker.js)
 */
importScripts('/service-worker.js');
