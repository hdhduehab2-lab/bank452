Add-Type -AssemblyName System.Drawing

function Generate-PwaIcon {
    param(
        [int]$size,
        [string]$outputPath,
        [bool]$isMaskable = $false
    )

    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit

    # Background Fill
    $bgColor = [System.Drawing.ColorTranslator]::FromHtml('#0b0f19')
    $g.Clear($bgColor)

    # Outer Card sizing (Maskable icons use 10% safe zone padding)
    $paddingRatio = if ($isMaskable) { 0.15 } else { 0.08 }
    $margin = [int]($size * $paddingRatio)
    $cardSize = $size - (2 * $margin)
    $cardRect = New-Object System.Drawing.Rectangle($margin, $margin, $cardSize, $cardSize)
    
    $gradBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        $cardRect,
        [System.Drawing.ColorTranslator]::FromHtml('#3b82f6'),
        [System.Drawing.ColorTranslator]::FromHtml('#8b5cf6'),
        45
    )

    # Draw rounded rectangle
    $radius = [int]($size * 0.22)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc($cardRect.X, $cardRect.Y, $radius, $radius, 180, 90)
    $path.AddArc($cardRect.Right - $radius, $cardRect.Y, $radius, $radius, 270, 90)
    $path.AddArc($cardRect.Right - $radius, $cardRect.Bottom - $radius, $radius, $radius, 0, 90)
    $path.AddArc($cardRect.X, $cardRect.Bottom - $radius, $radius, $radius, 90, 90)
    $path.CloseFigure()

    $g.FillPath($gradBrush, $path)

    # Draw Inner Wallet Shield
    $innerRatio = if ($isMaskable) { 0.42 } else { 0.50 }
    $innerSize = [int]($size * $innerRatio)
    $innerX = [int](($size - $innerSize) / 2)
    $innerY = [int](($size - $innerSize) / 2 + ($size * 0.02))

    # Inner Circle
    $circleBrush = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#ffffff'))
    $g.FillEllipse($circleBrush, $innerX, $innerY, $innerSize, $innerSize)

    # Dollar Symbol inside
    $fontSizeRatio = if ($isMaskable) { 0.26 } else { 0.32 }
    $fontSize = [float]($size * $fontSizeRatio)
    $font = New-Object System.Drawing.Font('Arial', $fontSize, [System.Drawing.FontStyle]::Bold)
    $textBrush = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml('#2563eb'))
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center

    $textRect = New-Object System.Drawing.RectangleF(0, 0, $size, $size)
    $g.DrawString('$', $font, $textBrush, $textRect, $sf)

    # Clean up
    $g.Dispose()
    $bmp.Save($outputPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "Generated icon: $outputPath ($size x $size)"
}

$iconsDir = Join-Path $PSScriptRoot "icons"
if (-not (Test-Path $iconsDir)) { New-Item -ItemType Directory -Path $iconsDir | Out-Null }

Generate-PwaIcon -size 192 -outputPath (Join-Path $iconsDir "icon-192.png")
Generate-PwaIcon -size 512 -outputPath (Join-Path $iconsDir "icon-512.png")
Generate-PwaIcon -size 512 -outputPath (Join-Path $iconsDir "icon-512-maskable.png") -isMaskable $true
