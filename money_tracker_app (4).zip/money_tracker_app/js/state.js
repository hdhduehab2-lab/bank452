/**
 * State & Data Management Module
 * Handles LocalStorage persistence, multi-currency balances, and CRUD operations.
 */

const STORAGE_KEY_TX = 'vt_transactions';
const STORAGE_KEY_CURR = 'vt_currencies';
const STORAGE_KEY_ACTIVE_CURR = 'vt_active_currency';

// Initial Default Currencies
const DEFAULT_CURRENCIES = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'EGP', symbol: 'ج.م', name: 'Egyptian Pound' },
  { code: 'JOD', symbol: 'JD', name: 'Jordanian Dinar' },
  { code: 'SAR', symbol: 'SR', name: 'Saudi Riyal' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'AED', symbol: 'AED', name: 'UAE Dirham' }
];

class AppState {
  constructor() {
    this.transactions = this.loadTransactions();
    this.currencies = this.loadCurrencies();
    this.activeCurrency = localStorage.getItem(STORAGE_KEY_ACTIVE_CURR) || 'USD';
  }

  // Loaders
  loadTransactions() {
    try {
      const data = localStorage.getItem(STORAGE_KEY_TX);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error('Failed to load transactions from localStorage', e);
      return [];
    }
  }

  saveTransactions() {
    localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(this.transactions));
  }

  loadCurrencies() {
    try {
      const data = localStorage.getItem(STORAGE_KEY_CURR);
      let list = data ? JSON.parse(data) : DEFAULT_CURRENCIES;
      
      // Auto-migrate: Ensure EGP is in the list
      if (!list.some(c => c.code === 'EGP')) {
        list.splice(2, 0, { code: 'EGP', symbol: 'ج.م', name: 'Egyptian Pound' });
        localStorage.setItem(STORAGE_KEY_CURR, JSON.stringify(list));
      }
      return list;
    } catch (e) {
      return DEFAULT_CURRENCIES;
    }
  }

  saveCurrencies() {
    localStorage.setItem(STORAGE_KEY_CURR, JSON.stringify(this.currencies));
  }

  setActiveCurrency(code) {
    this.activeCurrency = code;
    localStorage.setItem(STORAGE_KEY_ACTIVE_CURR, code);
  }

  getCurrencySymbol(code) {
    const c = this.currencies.find(item => item.code === (code || this.activeCurrency));
    return c ? c.symbol : '$';
  }

  // Transaction CRUD Operations
  addTransaction(txData) {
    const newTx = {
      id: 'tx_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      type: txData.type,                             // 'in' (deposit) or 'out' (withdrawal)
      amount: parseFloat(txData.amount) || 0,
      currency: txData.currency || this.activeCurrency,
      allocation: txData.allocation,                 // 'mine' or 'not_mine'
      beneficiary: txData.beneficiary ? txData.beneficiary.trim() : '',
      date: txData.date || new Date().toISOString().split('T')[0],
      category: txData.category || 'General',
      note: txData.note ? txData.note.trim() : '',
      createdAt: new Date().toISOString()
    };

    this.transactions.unshift(newTx); // Insert newest first
    this.saveTransactions();
    return newTx;
  }

  updateTransaction(id, updatedFields) {
    const index = this.transactions.findIndex(t => t.id === id);
    if (index !== -1) {
      this.transactions[index] = {
        ...this.transactions[index],
        type: updatedFields.type,
        amount: parseFloat(updatedFields.amount) || 0,
        currency: updatedFields.currency,
        allocation: updatedFields.allocation,
        beneficiary: updatedFields.beneficiary ? updatedFields.beneficiary.trim() : '',
        date: updatedFields.date,
        category: updatedFields.category,
        note: updatedFields.note ? updatedFields.note.trim() : ''
      };
      this.saveTransactions();
      return this.transactions[index];
    }
    return null;
  }

  deleteTransaction(id) {
    this.transactions = this.transactions.filter(t => t.id !== id);
    this.saveTransactions();
  }

  getTransactionById(id) {
    return this.transactions.find(t => t.id === id);
  }

  // Add Custom Currency
  addCurrency(code, symbol, name) {
    const cleanCode = code.trim().toUpperCase();
    if (this.currencies.some(c => c.code === cleanCode)) {
      return false; // Already exists
    }
    const newCurr = { code: cleanCode, symbol: symbol.trim(), name: name.trim() };
    this.currencies.push(newCurr);
    this.saveCurrencies();
    return true;
  }

  // Balance Calculations per Currency
  calculateBalances(currencyCode = this.activeCurrency) {
    const txs = this.transactions.filter(t => t.currency === currencyCode);

    let totalMine = 0;
    let totalNotMine = 0;
    let totalInflow = 0;
    let totalOutflow = 0;

    txs.forEach(t => {
      const amt = t.amount;
      if (t.type === 'in') {
        totalInflow += amt;
        if (t.allocation === 'mine') {
          totalMine += amt;
        } else {
          totalNotMine += amt;
        }
      } else if (t.type === 'out') {
        totalOutflow += amt;
        if (t.allocation === 'mine') {
          totalMine -= amt;
        } else {
          totalNotMine -= amt;
        }
      }
    });

    const totalBalance = totalMine + totalNotMine;

    return {
      currency: currencyCode,
      symbol: this.getCurrencySymbol(currencyCode),
      totalBalance,
      mineBalance: totalMine,
      notMineBalance: totalNotMine,
      totalInflow,
      totalOutflow,
      count: txs.length
    };
  }

  // Demo Sample Data Generator
  seedDemoData() {
    const today = new Date();
    const daysAgo = (days) => {
      const d = new Date(today);
      d.setDate(d.getDate() - days);
      return d.toISOString().split('T')[0];
    };

    const demoTxs = [
      {
        id: 'demo_1',
        type: 'in',
        amount: 3500.00,
        currency: 'USD',
        allocation: 'mine',
        beneficiary: '',
        date: daysAgo(12),
        category: 'Salary',
        note: 'Monthly salary deposit',
        createdAt: new Date(Date.now() - 12 * 86400000).toISOString()
      },
      {
        id: 'demo_2',
        type: 'in',
        amount: 850.00,
        currency: 'USD',
        allocation: 'not_mine',
        beneficiary: 'Ahmad Al-Mansoor',
        date: daysAgo(8),
        category: 'Escrow',
        note: 'Rent payment collected on behalf of Ahmad',
        createdAt: new Date(Date.now() - 8 * 86400000).toISOString()
      },
      {
        id: 'demo_3',
        type: 'in',
        amount: 400.00,
        currency: 'USD',
        allocation: 'not_mine',
        beneficiary: 'Sarah (Sister)',
        date: daysAgo(5),
        category: 'Transfer',
        note: 'University fee transfer from father to pass to Sarah',
        createdAt: new Date(Date.now() - 5 * 86400000).toISOString()
      },
      {
        id: 'demo_4',
        type: 'out',
        amount: 400.00,
        currency: 'USD',
        allocation: 'not_mine',
        beneficiary: 'Sarah (Sister)',
        date: daysAgo(3),
        category: 'Transfer',
        note: 'Paid Sarah university fees',
        createdAt: new Date(Date.now() - 3 * 86400000).toISOString()
      },
      {
        id: 'demo_5',
        type: 'out',
        amount: 650.00,
        currency: 'USD',
        allocation: 'mine',
        beneficiary: '',
        date: daysAgo(2),
        category: 'Bills',
        note: 'Credit card statement payment',
        createdAt: new Date(Date.now() - 2 * 86400000).toISOString()
      },
      {
        id: 'demo_6',
        type: 'in',
        amount: 1200.00,
        currency: 'JOD',
        allocation: 'mine',
        beneficiary: '',
        date: daysAgo(10),
        category: 'Business',
        note: 'Consulting invoice payment',
        createdAt: new Date(Date.now() - 10 * 86400000).toISOString()
      },
      {
        id: 'demo_7',
        type: 'in',
        amount: 300.00,
        currency: 'JOD',
        allocation: 'not_mine',
        beneficiary: 'Tareq - Car Deposit',
        date: daysAgo(4),
        category: 'Escrow',
        note: 'Car sale deposit held for Tareq',
        createdAt: new Date(Date.now() - 4 * 86400000).toISOString()
      }
    ];

    this.transactions = demoTxs;
    this.saveTransactions();
  }

  clearAllData() {
    this.transactions = [];
    localStorage.removeItem(STORAGE_KEY_TX);
  }
}

// Global Singleton Instance
window.state = new AppState();
