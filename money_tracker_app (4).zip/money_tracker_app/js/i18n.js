/**
 * Internationalization (i18n) Module
 * Supports English (LTR) and Arabic (RTL)
 */

const translations = {
  en: {
    tagline: "Money Flow Manager",
    currency: "Currency:",
    activeCurrency: "Active Currency",
    totalBalance: "Total Account Balance",
    mine: "Mine",
    notMine: "Not Mine",
    amountMine: "Owner Funds (Mine)",
    amountNotMine: "Held Funds (Not Mine)",
    addDeposit: "Deposit (In)",
    addWithdrawal: "Withdraw (Out)",
    recentTransactions: "Recent Activity",
    viewAll: "View All",

    // History
    historyTitle: "Transaction History",
    searchPlaceholder: "Search notes, beneficiary...",
    filterAllTypes: "All Movement Types",
    filterAllAllocations: "All Allocations",
    allCurrencies: "All Currencies",
    deposit: "Deposit (In)",
    withdrawal: "Withdrawal (Out)",
    mineOnly: "Mine Only",
    notMineOnly: "Not Mine Only",

    // Stats
    statsTitle: "Analytics & Breakdown",
    chartSplitTitle: "Balance Ownership Split",
    chartFlowTitle: "Total Inflow vs Outflow",
    totalInflow: "Total Deposits",
    totalOutflow: "Total Withdrawals",

    // Settings
    settingsTitle: "Settings & Currencies",
    currenciesTitle: "Active Currencies",
    currenciesSubtitle: "Manage supported accounts & currencies",
    addCurrency: "Add Currency",
    dataManagement: "Data Management & Backup",
    dataSubtitle: "Export transactions or seed test data for quick evaluation.",
    loadDemoData: "Load Demo Sample Data",
    exportCSV: "Export to CSV",
    backupJSON: "Backup Data (JSON)",
    restoreJSON: "Restore Data (JSON)",
    clearAllData: "Clear All Local Data",

    // Navigation
    navDashboard: "Dashboard",
    navHistory: "History",
    navStats: "Stats",
    navSettings: "Settings",

    // Form / Modals
    newTransaction: "New Transaction",
    editTransaction: "Edit Transaction",
    amount: "Amount",
    allocationTitle: "Whose Money is this?",
    beneficiaryLabel: "Person Name / Note (For Whom?)",
    beneficiaryPlaceholder: "e.g. Ahmad (Rent transfer), Sarah...",
    date: "Date",
    category: "Category",
    notes: "Notes / Reference",
    notesPlaceholder: "Optional notes...",
    cancel: "Cancel",
    saveTransaction: "Save Transaction",
    delete: "Delete",
    add: "Add",

    // Categories
    catGeneral: "General",
    catSalary: "Salary",
    catTransfer: "Transfer",
    catBusiness: "Business",
    catPersonal: "Personal",
    catBills: "Bills",
    catEscrow: "Escrow / Pass-through",

    // Dialogs
    confirmDeleteTitle: "Delete Transaction?",
    confirmDeleteMessage: "Are you sure you want to delete this transaction? This will update your balance.",
    addNewCurrencyTitle: "Add Custom Currency",
    currCode: "Currency Code (3 letters)",
    currSymbol: "Symbol",
    currName: "Currency Name",

    // Toasts
    txAdded: "Transaction added successfully!",
    txUpdated: "Transaction updated successfully!",
    txDeleted: "Transaction deleted.",
    demoLoaded: "Demo sample data loaded!",
    dataCleared: "All data cleared.",
    currencyAdded: "New currency added!",
    importedSuccess: "Data restored successfully!",
    importedError: "Failed to parse JSON file.",

    // Converter
    converterTitle: "Live Currency Converter",
    converterSubtitle: "Check real-time exchange rates. Does not affect saved balances.",
    fromCurrency: "From Currency",
    toCurrency: "To Currency",
    convertedAmount: "Converted Result",
    exchangeRateLabel: "Exchange Rate",
    lastUpdatedLabel: "Last Updated",
    refreshRates: "Refresh Live Rates",
    offlineNotice: "Unable to fetch live exchange rates. Please check your internet connection.",
    loadingRates: "Fetching latest exchange rates..."
  },
  ar: {
    tagline: "إدارة حركة الأموال",
    currency: "العملة:",
    activeCurrency: "العملة النشطة",
    totalBalance: "إجمالي رصيد الحساب",
    mine: "خاص بي",
    notMine: "ليس لي",
    amountMine: "أموالي الخاصة (لي)",
    amountNotMine: "أموال أمانة (ليست لي)",
    addDeposit: "إيداع (وارد)",
    addWithdrawal: "سحب (صادر)",
    recentTransactions: "أحدث العمليات",
    viewAll: "عرض الكل",

    // History
    historyTitle: "سجل العمليات",
    searchPlaceholder: "بحث في الملاحظات أو اسم الشخص...",
    filterAllTypes: "جميع أنواع الحركة",
    filterAllAllocations: "جميع التخصيصات",
    allCurrencies: "جميع العملات",
    deposit: "إيداع (وارد)",
    withdrawal: "سحب (صادر)",
    mineOnly: "خاص بي فقط",
    notMineOnly: "ليست لي فقط",

    // Stats
    statsTitle: "الإحصائيات والتحليل",
    chartSplitTitle: "نسبة توزيع ملكية الرصيد",
    chartFlowTitle: "إجمالي المقبوضات مقابل المدفوعات",
    totalInflow: "إجمالي الإيداعات",
    totalOutflow: "إجمالي السحوبات",

    // Settings
    settingsTitle: "الإعدادات والعملات",
    currenciesTitle: "العملات المعتمدة",
    currenciesSubtitle: "إدارة الحسابات والعملات المدعومة",
    addCurrency: "إضافة عملة",
    dataManagement: "إدارة البيانات والنسخ الاحتياطي",
    dataSubtitle: "تصدير العمليات أو تحميل بيانات تجريبية سريعة.",
    loadDemoData: "تحميل بيانات تجريبية",
    exportCSV: "تصدير إلى CSV",
    backupJSON: "نسخ احتياطي (JSON)",
    restoreJSON: "استعادة البيانات (JSON)",
    clearAllData: "مسح جميع البيانات المحفوظة",

    // Navigation
    navDashboard: "الرئيسية",
    navHistory: "السجل",
    navStats: "الإحصائيات",
    navSettings: "الإعدادات",

    // Form / Modals
    newTransaction: "عملية جديدة",
    editTransaction: "تعديل العملية",
    amount: "المبلغ",
    allocationTitle: "لمن تعود هذه الأموال؟",
    beneficiaryLabel: "اسم الشخص / البيان (لحساب من؟)",
    beneficiaryPlaceholder: "مثال: أحمد (إيجار)، سارة...",
    date: "التاريخ",
    category: "الفئة",
    notes: "ملاحظات / مرجع",
    notesPlaceholder: "ملاحظات اختيارية...",
    cancel: "إلغاء",
    saveTransaction: "حفظ العملية",
    delete: "حذف",
    add: "إضافة",

    // Categories
    catGeneral: "عام",
    catSalary: "راتب",
    catTransfer: "تحويل",
    catBusiness: "أعمال",
    catPersonal: "شخصي",
    catBills: "فواتير",
    catEscrow: "أمانة / تحويل عابر",

    // Dialogs
    confirmDeleteTitle: "حذف العملية؟",
    confirmDeleteMessage: "هل أنت تأكد من رغبتك في حذف هذه العملية؟ سيتم تحديث الرصيد تلقائياً.",
    addNewCurrencyTitle: "إضافة عملة مخصصة",
    currCode: "رمز العملة (3 حروف)",
    currSymbol: "الرمز",
    currName: "اسم العملة",

    // Toasts
    txAdded: "تمت إضافة العملية بنجاح!",
    txUpdated: "تم تحديث العملية بنجاح!",
    txDeleted: "تم حذف العملية.",
    demoLoaded: "تم تحميل البيانات التجريبية!",
    dataCleared: "تم مسح كافة البيانات.",
    currencyAdded: "تمت إضافة العملة بنجاح!",
    importedSuccess: "تمت استعادة البيانات بنجاح!",
    importedError: "فشل في قراءة ملف JSON.",

    // Converter
    converterTitle: "مُحوِّل العملات وأسعار الصرف الحية",
    converterSubtitle: "استعلام مباشر عن أسعار الصرف الحالية. لا يغير الرصيد المحفوظ.",
    fromCurrency: "من عملة",
    toCurrency: "إلى عملة",
    convertedAmount: "النتيجة المحولة",
    exchangeRateLabel: "سعر الصرف",
    lastUpdatedLabel: "آخر تحديث",
    refreshRates: "تحديث الأسعار الحية",
    offlineNotice: "تعذر جلب أسعار الصرف الحية. يرجى التحقق من الاتصال بالإنترنت.",
    loadingRates: "جاري جلب أسعار الصرف الحالية..."
  }
};

let currentLang = localStorage.getItem('vt_lang') || 'en';

function t(key) {
  if (translations[currentLang] && translations[currentLang][key]) {
    return translations[currentLang][key];
  }
  return translations.en[key] || key;
}

function setLanguage(lang) {
  currentLang = lang;
  localStorage.setItem('vt_lang', lang);
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.lang = lang;

  // Update lang button label
  const langLabel = document.getElementById('lang-label');
  if (langLabel) {
    langLabel.textContent = lang === 'ar' ? 'English' : 'العربية';
  }

  // Update text for all elements with data-i18n attributes
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.getAttribute('data-i18n');
    if (translations[lang] && translations[lang][k]) {
      el.textContent = translations[lang][k];
    }
  });

  // Update placeholders
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const k = el.getAttribute('data-i18n-placeholder');
    if (translations[lang] && translations[lang][k]) {
      el.placeholder = translations[lang][k];
    }
  });
}
