/**
 * Statistics & Chart Rendering Engine
 * Custom HTML5 Canvas visualizer for financial metrics (Donut Split & Bar Charts)
 */

function renderOwnershipDonutChart(canvasId, mineAmount, notMineAmount, symbol) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || 300;
  const height = canvas.clientHeight || 220;

  canvas.width = width * dpr;
  canvas.height = height * dpr;
  ctx.scale(dpr, dpr);

  ctx.clearRect(0, 0, width, height);

  const total = Math.max(0, mineAmount) + Math.max(0, notMineAmount);
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = Math.min(centerX, centerY) - 24;
  const innerRadius = radius * 0.65;

  if (total <= 0) {
    // Empty Chart placeholder ring
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    ctx.arc(centerX, centerY, innerRadius, 0, 2 * Math.PI, true);
    ctx.fillStyle = '#374151';
    ctx.fill();

    ctx.fillStyle = '#9ca3af';
    ctx.font = '600 13px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('No Funds Data', centerX, centerY);
    return;
  }

  const mineRatio = Math.max(0, mineAmount) / total;
  const notMineRatio = Math.max(0, notMineAmount) / total;

  let startAngle = -Math.PI / 2;

  // 1. Draw Mine Slice (Green)
  const mineAngle = mineRatio * 2 * Math.PI;
  if (mineAngle > 0) {
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, startAngle + mineAngle);
    ctx.arc(centerX, centerY, innerRadius, startAngle + mineAngle, startAngle, true);
    ctx.closePath();
    
    const grad1 = ctx.createLinearGradient(0, 0, width, height);
    grad1.addColorStop(0, '#10b981');
    grad1.addColorStop(1, '#34d399');
    ctx.fillStyle = grad1;
    ctx.fill();
    startAngle += mineAngle;
  }

  // 2. Draw Not Mine Slice (Violet)
  const notMineAngle = notMineRatio * 2 * Math.PI;
  if (notMineAngle > 0) {
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, startAngle + notMineAngle);
    ctx.arc(centerX, centerY, innerRadius, startAngle + notMineAngle, startAngle, true);
    ctx.closePath();

    const grad2 = ctx.createLinearGradient(0, 0, width, height);
    grad2.addColorStop(0, '#8b5cf6');
    grad2.addColorStop(1, '#a78bfa');
    ctx.fillStyle = grad2;
    ctx.fill();
  }

  // Center Total Text
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#9ca3af';
  ctx.font = '500 11px sans-serif';
  ctx.fillText(t('totalBalance'), centerX, centerY - 10);

  ctx.fillStyle = '#f9fafb';
  ctx.font = 'bold 15px sans-serif';
  const formattedTotal = symbol + (total).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  ctx.fillText(formattedTotal, centerX, centerY + 10);
}

function renderCashFlowBarChart(canvasId, totalInflow, totalOutflow, symbol) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || 300;
  const height = canvas.clientHeight || 200;

  canvas.width = width * dpr;
  canvas.height = height * dpr;
  ctx.scale(dpr, dpr);

  ctx.clearRect(0, 0, width, height);

  const maxVal = Math.max(totalInflow, totalOutflow, 1);
  const barWidth = 50;
  const chartBottom = height - 40;
  const maxBarHeight = height - 70;

  // 1. Draw Inflow Bar (Green)
  const inBarHeight = (totalInflow / maxVal) * maxBarHeight;
  const inX = width / 4 - barWidth / 2;
  const inY = chartBottom - inBarHeight;

  ctx.beginPath();
  ctx.roundRect(inX, inY, barWidth, inBarHeight, [8, 8, 0, 0]);
  const gradIn = ctx.createLinearGradient(inX, inY, inX, chartBottom);
  gradIn.addColorStop(0, '#10b981');
  gradIn.addColorStop(1, '#059669');
  ctx.fillStyle = gradIn;
  ctx.fill();

  // Inflow Label & Value
  ctx.textAlign = 'center';
  ctx.fillStyle = '#f9fafb';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText(symbol + totalInflow.toLocaleString('en-US', { minimumFractionDigits: 0 }), inX + barWidth / 2, inY - 8);
  ctx.fillStyle = '#9ca3af';
  ctx.font = '500 12px sans-serif';
  ctx.fillText(t('deposit'), inX + barWidth / 2, chartBottom + 20);

  // 2. Draw Outflow Bar (Red)
  const outBarHeight = (totalOutflow / maxVal) * maxBarHeight;
  const outX = (3 * width) / 4 - barWidth / 2;
  const outY = chartBottom - outBarHeight;

  ctx.beginPath();
  ctx.roundRect(outX, outY, barWidth, outBarHeight, [8, 8, 0, 0]);
  const gradOut = ctx.createLinearGradient(outX, outY, outX, chartBottom);
  gradOut.addColorStop(0, '#ef4444');
  gradOut.addColorStop(1, '#dc2626');
  ctx.fillStyle = gradOut;
  ctx.fill();

  // Outflow Label & Value
  ctx.textAlign = 'center';
  ctx.fillStyle = '#f9fafb';
  ctx.font = 'bold 12px sans-serif';
  ctx.fillText(symbol + totalOutflow.toLocaleString('en-US', { minimumFractionDigits: 0 }), outX + barWidth / 2, outY - 8);
  ctx.fillStyle = '#9ca3af';
  ctx.font = '500 12px sans-serif';
  ctx.fillText(t('withdrawal'), outX + barWidth / 2, chartBottom + 20);

  // Baseline
  ctx.beginPath();
  ctx.moveTo(20, chartBottom);
  ctx.lineTo(width - 20, chartBottom);
  ctx.strokeStyle = '#374151';
  ctx.lineWidth = 1;
  ctx.stroke();
}
