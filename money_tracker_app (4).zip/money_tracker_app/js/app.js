/**
 * Main Application Controller
 * Handles events, navigation, form submissions, theme/language toggles, and data export/import.
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Initial Setup & Seed Data if empty
  if (window.state.transactions.length === 0) {
    window.state.seedDemoData();
  }

  // Set initial language from storage
  const lang = localStorage.getItem('vt_lang') || 'en';
  setLanguage(lang);

  // Initialize UI Views
  refreshAllViews();

  // 2. Bottom Navigation Switching
  document.querySelectorAll('.app-bottom-nav .nav-item').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const viewTarget = btn.dataset.view;
      
      // Update active nav button
      document.querySelectorAll('.app-bottom-nav .nav-item').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      // Update active view section
      document.querySelectorAll('.app-view').forEach(view => {
        view.classList.remove('active');
        if (view.id === `view-${viewTarget}`) {
          view.classList.add('active');
        }
      });

      // Refresh view contents
      if (viewTarget === 'dashboard') renderDashboard();
      if (viewTarget === 'history') renderHistory();
      if (viewTarget === 'stats') renderStatsView();
      if (viewTarget === 'settings') renderSettingsView();
    });
  });

  // View All History Link
  document.getElementById('btn-view-all-history')?.addEventListener('click', () => {
    document.querySelector('.nav-item[data-view="history"]')?.click();
  });

  // 3. Quick Action Buttons & FAB
  document.getElementById('fab-add')?.addEventListener('click', () => {
    openTransactionModal('in');
  });

  document.getElementById('btn-quick-deposit')?.addEventListener('click', () => {
    openTransactionModal('in');
  });

  document.getElementById('btn-quick-withdraw')?.addEventListener('click', () => {
    openTransactionModal('out');
  });

  // 4. Modal Segmented Controls
  // Movement Type Toggle (Deposit vs Withdrawal)
  document.querySelectorAll('.type-segmented .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.type-segmented .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Allocation Toggle (Mine vs Not Mine)
  document.querySelectorAll('.allocation-segmented .segment-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.allocation-segmented .segment-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const isNotMine = btn.dataset.allocation === 'not_mine';
      const groupBeneficiary = document.getElementById('group-beneficiary');
      if (groupBeneficiary) {
        groupBeneficiary.style.display = isNotMine ? 'block' : 'none';
        if (isNotMine) {
          document.getElementById('tx-beneficiary')?.focus();
        }
      }
    });
  });

  // Currency select change -> update symbol addon
  document.getElementById('tx-currency')?.addEventListener('change', (e) => {
    const sym = window.state.getCurrencySymbol(e.target.value);
    const addon = document.getElementById('tx-currency-symbol');
    if (addon) addon.textContent = sym;
  });

  // 5. Transaction Form Submission (Add or Edit)
  document.getElementById('form-transaction')?.addEventListener('submit', (e) => {
    e.preventDefault();

    const txId = document.getElementById('tx-id').value;
    const activeTypeBtn = document.querySelector('.type-segmented .segment-btn.active');
    const activeAllocBtn = document.querySelector('.allocation-segmented .segment-btn.active');

    const type = activeTypeBtn ? activeTypeBtn.dataset.type : 'in';
    const allocation = activeAllocBtn ? activeAllocBtn.dataset.allocation : 'mine';
    const amount = document.getElementById('tx-amount').value;
    const currency = document.getElementById('tx-currency').value;
    const beneficiary = document.getElementById('tx-beneficiary').value;
    const date = document.getElementById('tx-date').value;
    const category = document.getElementById('tx-category').value;
    const note = document.getElementById('tx-note').value;

    if (allocation === 'not_mine' && !beneficiary.trim()) {
      showToast('Please enter beneficiary name for Not Mine funds', 'error');
      document.getElementById('tx-beneficiary').focus();
      return;
    }

    if (txId) {
      // Edit existing
      window.state.updateTransaction(txId, {
        type, amount, currency, allocation, beneficiary, date, category, note
      });
      showToast(t('txUpdated'), 'success');
    } else {
      // Add new
      window.state.addTransaction({
        type, amount, currency, allocation, beneficiary, date, category, note
      });
      showToast(t('txAdded'), 'success');
    }

    closeTransactionModal();
    refreshAllViews();
  });

  // Modal Close buttons
  document.getElementById('close-tx-modal')?.addEventListener('click', closeTransactionModal);
  document.getElementById('cancel-tx-modal')?.addEventListener('click', closeTransactionModal);
  document.getElementById('close-delete-modal')?.addEventListener('click', closeDeleteModal);
  document.getElementById('cancel-delete-btn')?.addEventListener('click', closeDeleteModal);

  // 6. Transaction Item Click (Edit or Delete Trigger)
  document.addEventListener('click', (e) => {
    const card = e.target.closest('.tx-card');
    if (card) {
      const txId = card.dataset.id;
      const tx = window.state.getTransactionById(txId);
      if (tx) {
        // Open Edit Modal by default
        openTransactionModal(tx.type, tx);
      }
    }
  });

  // Delete Confirmation Handler
  document.getElementById('confirm-delete-btn')?.addEventListener('click', () => {
    const txId = document.getElementById('confirm-delete-btn').dataset.id;
    if (txId) {
      window.state.deleteTransaction(txId);
      showToast(t('txDeleted'), 'success');
      closeDeleteModal();
      closeTransactionModal();
      refreshAllViews();
    }
  });

  // Add Delete option to edit modal footer if editing
  const txForm = document.getElementById('form-transaction');
  if (txForm) {
    const modalFooter = txForm.querySelector('.modal-footer');
    if (modalFooter && !document.getElementById('btn-tx-modal-delete')) {
      const deleteBtn = document.createElement('button');
      deleteBtn.type = 'button';
      deleteBtn.id = 'btn-tx-modal-delete';
      deleteBtn.className = 'btn-danger';
      deleteBtn.innerHTML = `<i data-lucide="trash-2"></i> ${t('delete')}`;
      deleteBtn.style.display = 'none'; // Shown when editing

      deleteBtn.addEventListener('click', () => {
        const txId = document.getElementById('tx-id').value;
        const tx = window.state.getTransactionById(txId);
        if (tx) openDeleteModal(tx);
      });

      modalFooter.prepend(deleteBtn);
    }
  }

  // Observer to toggle delete button in modal
  const observer = new MutationObserver(() => {
    const txId = document.getElementById('tx-id')?.value;
    const delBtn = document.getElementById('btn-tx-modal-delete');
    if (delBtn) delBtn.style.display = txId ? 'flex' : 'none';
  });
  observer.observe(document.getElementById('modal-transaction'), { attributes: true });

  // 7. Currency Bar Pills Click Handler
  document.addEventListener('click', (e) => {
    const pill = e.target.closest('.curr-pill');
    if (pill) {
      const code = pill.dataset.code;
      window.state.setActiveCurrency(code);
      renderDashboard();
      renderStatsView();
    }
  });

  // 8. History Search & Filter Handlers
  const historySearch = document.getElementById('history-search-input');
  const clearSearch = document.getElementById('clear-search-btn');

  historySearch?.addEventListener('input', () => {
    if (clearSearch) clearSearch.classList.toggle('hidden', !historySearch.value);
    renderHistory();
  });

  clearSearch?.addEventListener('click', () => {
    if (historySearch) historySearch.value = '';
    clearSearch.classList.add('hidden');
    renderHistory();
  });

  document.getElementById('filter-type-select')?.addEventListener('change', renderHistory);
  document.getElementById('filter-allocation-select')?.addEventListener('change', renderHistory);
  document.getElementById('filter-currency-select')?.addEventListener('change', renderHistory);
  document.getElementById('stats-currency-select')?.addEventListener('change', renderStatsView);

  // Currency Converter Event Handlers
  document.getElementById('converter-from-select')?.addEventListener('change', async (e) => {
    const fromCode = e.target.value;
    if (!ratesCache[fromCode]) {
      await fetchLiveExchangeRates(fromCode);
    }
    updateConverterView();
  });

  document.getElementById('converter-to-select')?.addEventListener('change', () => {
    updateConverterView();
  });

  document.getElementById('converter-amount-input')?.addEventListener('input', () => {
    updateConverterView();
  });

  document.getElementById('btn-refresh-rates')?.addEventListener('click', async () => {
    const fromCode = document.getElementById('converter-from-select')?.value || 'USD';
    delete ratesCache[fromCode];
    await fetchLiveExchangeRates(fromCode);
    updateConverterView();
    showToast('Rates refreshed!', 'success');
  });

  // 9. Currency Management Modal
  document.getElementById('btn-add-currency')?.addEventListener('click', () => {
    document.getElementById('modal-add-currency')?.classList.remove('hidden');
  });

  document.getElementById('close-currency-modal')?.addEventListener('click', () => {
    document.getElementById('modal-add-currency')?.classList.add('hidden');
  });
  document.getElementById('cancel-currency-modal')?.addEventListener('click', () => {
    document.getElementById('modal-add-currency')?.classList.add('hidden');
  });

  document.getElementById('form-add-currency')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const code = document.getElementById('curr-code').value;
    const symbol = document.getElementById('curr-symbol').value;
    const name = document.getElementById('curr-name').value;

    const success = window.state.addCurrency(code, symbol, name);
    if (success) {
      showToast(t('currencyAdded'), 'success');
      document.getElementById('modal-add-currency').classList.add('hidden');
      document.getElementById('form-add-currency').reset();
      refreshAllViews();
    } else {
      showToast('Currency code already exists!', 'error');
    }
  });

  // 10. Demo Data & Backup/Restore
  document.getElementById('btn-seed-data')?.addEventListener('click', () => {
    window.state.seedDemoData();
    showToast(t('demoLoaded'), 'success');
    refreshAllViews();
  });

  document.getElementById('btn-clear-all')?.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear all transaction records?')) {
      window.state.clearAllData();
      showToast(t('dataCleared'), 'success');
      refreshAllViews();
    }
  });

  // Export CSV
  document.getElementById('btn-export-csv')?.addEventListener('click', () => {
    const txs = window.state.transactions;
    if (txs.length === 0) {
      showToast('No transactions to export', 'error');
      return;
    }

    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'ID,Type,Amount,Currency,Allocation,Beneficiary,Date,Category,Note\n';

    txs.forEach(t => {
      const row = [
        t.id,
        t.type,
        t.amount,
        t.currency,
        t.allocation,
        `"${(t.beneficiary || '').replace(/"/g, '""')}"`,
        t.date,
        t.category,
        `"${(t.note || '').replace(/"/g, '""')}"`
      ].join(',');
      csvContent += row + '\n';
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `vaulttrack_transactions_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  });

  // Export JSON
  document.getElementById('btn-export-json')?.addEventListener('click', () => {
    const backupData = {
      transactions: window.state.transactions,
      currencies: window.state.currencies,
      version: '1.0',
      exportedAt: new Date().toISOString()
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `vaulttrack_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  });

  // Import JSON
  document.getElementById('import-json-file')?.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target.result);
        if (parsed.transactions && Array.isArray(parsed.transactions)) {
          window.state.transactions = parsed.transactions;
          if (parsed.currencies && Array.isArray(parsed.currencies)) {
            window.state.currencies = parsed.currencies;
            window.state.saveCurrencies();
          }
          window.state.saveTransactions();
          showToast(t('importedSuccess'), 'success');
          refreshAllViews();
        } else {
          showToast(t('importedError'), 'error');
        }
      } catch (err) {
        showToast(t('importedError'), 'error');
      }
    };
    reader.readAsText(file);
  });

  // 11. Header Buttons (Device Mode, Theme, Language)
  document.getElementById('toggle-frame-btn')?.addEventListener('click', () => {
    document.getElementById('app-shell')?.classList.toggle('device-mode');
  });

  document.getElementById('toggle-theme-btn')?.addEventListener('click', () => {
    document.body.classList.toggle('theme-dark');
    document.body.classList.toggle('theme-light');
    const isDark = document.body.classList.contains('theme-dark');
    const themeIcon = document.getElementById('theme-icon');
    if (themeIcon) {
      themeIcon.setAttribute('data-lucide', isDark ? 'moon' : 'sun');
      if (window.lucide) lucide.createIcons();
    }
  });

  document.getElementById('toggle-lang-btn')?.addEventListener('click', () => {
    const nextLang = currentLang === 'en' ? 'ar' : 'en';
    setLanguage(nextLang);
    refreshAllViews();
  });
});
