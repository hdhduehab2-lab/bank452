/**
 * UI Rendering & Interaction Handler
 * Manages DOM updates, modals, forms, toast notifications, and list rendering.
 */

// Helper to format currency numbers cleanly
function formatMoney(amount, symbol = '$') {
  const num = Number(amount) || 0;
  const isNegative = num < 0;
  const formatted = Math.abs(num).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  return (isNegative ? '-' : '') + symbol + formatted;
}

// Toast Notifications
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i data-lucide="${type === 'success' ? 'check-circle' : 'alert-circle'}"></i> <span>${message}</span>`;
  
  container.appendChild(toast);
  if (window.lucide) lucide.createIcons();

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-10px)';
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

// 1. Dashboard View Renderer
function renderDashboard() {
  const activeCurr = window.state.activeCurrency;
  const balances = window.state.calculateBalances(activeCurr);
  const symbol = balances.symbol;

  // Currency Pills Ticker
  const pillsContainer = document.getElementById('currency-pills-container');
  if (pillsContainer) {
    pillsContainer.innerHTML = window.state.currencies.map(c => `
      <button class="curr-pill ${c.code === activeCurr ? 'active' : ''}" data-code="${c.code}">
        <span class="curr-symbol">${c.symbol}</span>
        <span>${c.code}</span>
      </button>
    `).join('');
  }

  // Hero Card Amounts
  document.getElementById('card-currency-tag').textContent = activeCurr;
  document.getElementById('total-balance-display').textContent = formatMoney(balances.totalBalance, symbol);
  document.getElementById('mine-balance-display').textContent = formatMoney(balances.mineBalance, symbol);
  document.getElementById('not-mine-balance-display').textContent = formatMoney(balances.notMineBalance, symbol);

  // Mine vs Not Mine Percentage Split Bar
  const absMine = Math.max(0, balances.mineBalance);
  const absNotMine = Math.max(0, balances.notMineBalance);
  const totalPositive = absMine + absNotMine;

  let minePct = 50;
  let notMinePct = 50;

  if (totalPositive > 0) {
    minePct = Math.round((absMine / totalPositive) * 100);
    notMinePct = 100 - minePct;
  }

  const mineBar = document.getElementById('split-mine-bar');
  const notMineBar = document.getElementById('split-not-mine-bar');
  if (mineBar) mineBar.style.width = minePct + '%';
  if (notMineBar) notMineBar.style.width = notMinePct + '%';

  document.getElementById('split-mine-pct').textContent = minePct + '%';
  document.getElementById('split-not-mine-pct').textContent = notMinePct + '%';

  // Recent Transactions (Limit to 5)
  const recentList = document.getElementById('recent-transactions-list');
  if (recentList) {
    const recentTxs = window.state.transactions.slice(0, 5);
    if (recentTxs.length === 0) {
      recentList.innerHTML = `
        <div class="empty-state">
          <i data-lucide="receipt"></i>
          <p>No recent activity found.</p>
          <small>Tap the + button to add your first transaction.</small>
        </div>
      `;
    } else {
      recentList.innerHTML = recentTxs.map(t => renderTransactionCardHtml(t)).join('');
    }
  }

  if (window.lucide) lucide.createIcons();
}

// Transaction Card HTML Template
function renderTransactionCardHtml(tx) {
  const sym = window.state.getCurrencySymbol(tx.currency);
  const isIn = tx.type === 'in';
  const isMine = tx.allocation === 'mine';
  const sign = isIn ? '+' : '-';
  const categoryLabel = tx.category || 'General';

  const beneficiaryText = (!isMine && tx.beneficiary) ? ` • ${tx.beneficiary}` : '';
  const noteText = tx.note ? ` (${tx.note})` : '';

  return `
    <div class="tx-card" data-id="${tx.id}">
      <div class="tx-card-left">
        <div class="tx-type-icon ${isIn ? 'in' : 'out'}">
          <i data-lucide="${isIn ? 'arrow-down-left' : 'arrow-up-right'}"></i>
        </div>
        <div class="tx-details">
          <div class="tx-title">
            <span>${categoryLabel}${noteText}</span>
          </div>
          <div class="tx-meta">
            <span class="badge-tag ${isMine ? 'badge-mine' : 'badge-not-mine'}">
              ${isMine ? t('mine') : t('notMine')}
            </span>
            <span>${tx.date}${beneficiaryText}</span>
          </div>
        </div>
      </div>
      <div class="tx-card-right">
        <div class="tx-amount ${isIn ? 'in' : 'out'}">
          ${sign}${formatMoney(tx.amount, sym)}
        </div>
        <div class="tx-date">${tx.currency}</div>
      </div>
    </div>
  `;
}

// 2. Full History View Renderer
function renderHistory() {
  const searchVal = (document.getElementById('history-search-input')?.value || '').toLowerCase().trim();
  const typeFilter = document.getElementById('filter-type-select')?.value || 'all';
  const allocFilter = document.getElementById('filter-allocation-select')?.value || 'all';
  const currFilter = document.getElementById('filter-currency-select')?.value || 'all';

  let filtered = window.state.transactions;

  if (typeFilter !== 'all') {
    filtered = filtered.filter(tx => tx.type === typeFilter);
  }

  if (allocFilter !== 'all') {
    filtered = filtered.filter(tx => tx.allocation === allocFilter);
  }

  if (currFilter !== 'all') {
    filtered = filtered.filter(tx => tx.currency === currFilter);
  }

  if (searchVal) {
    filtered = filtered.filter(tx => {
      const notes = (tx.note || '').toLowerCase();
      const beneficiary = (tx.beneficiary || '').toLowerCase();
      const cat = (tx.category || '').toLowerCase();
      const amt = tx.amount.toString();
      return notes.includes(searchVal) || beneficiary.includes(searchVal) || cat.includes(searchVal) || amt.includes(searchVal);
    });
  }

  const badge = document.getElementById('history-count-badge');
  if (badge) badge.textContent = `${filtered.length} items`;

  const container = document.getElementById('full-history-list');
  if (container) {
    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <i data-lucide="filter-x"></i>
          <p>No transactions match your search/filters.</p>
        </div>
      `;
    } else {
      container.innerHTML = filtered.map(tx => renderTransactionCardHtml(tx)).join('');
    }
  }

  if (window.lucide) lucide.createIcons();
}

// Populate Currency Dropdowns across app
function updateCurrencyDropdowns() {
  const currencies = window.state.currencies;
  
  const optionsHtml = currencies.map(c => `
    <option value="${c.code}">${c.code} (${c.symbol}) - ${c.name}</option>
  `).join('');

  const txCurrSelect = document.getElementById('tx-currency');
  if (txCurrSelect) txCurrSelect.innerHTML = optionsHtml;

  const historyCurrSelect = document.getElementById('filter-currency-select');
  if (historyCurrSelect) {
    historyCurrSelect.innerHTML = `<option value="all" data-i18n="allCurrencies">${t('allCurrencies')}</option>` + optionsHtml;
  }

  const statsCurrSelect = document.getElementById('stats-currency-select');
  if (statsCurrSelect) {
    statsCurrSelect.innerHTML = optionsHtml;
    statsCurrSelect.value = window.state.activeCurrency;
  }
}

// 3. Stats View Renderer
function renderStatsView() {
  updateCurrencyDropdowns();
  const selectedCurr = document.getElementById('stats-currency-select')?.value || window.state.activeCurrency;
  const balances = window.state.calculateBalances(selectedCurr);

  renderOwnershipDonutChart('chart-ownership-canvas', balances.mineBalance, balances.notMineBalance, balances.symbol);
  renderCashFlowBarChart('chart-cashflow-canvas', balances.totalInflow, balances.totalOutflow, balances.symbol);

  const summaryBox = document.getElementById('stats-split-summary');
  if (summaryBox) {
    summaryBox.innerHTML = `
      <div class="summary-metric">
        <label>${t('amountMine')}</label>
        <span style="color: var(--accent-mine);">${formatMoney(balances.mineBalance, balances.symbol)}</span>
      </div>
      <div class="summary-metric">
        <label>${t('amountNotMine')}</label>
        <span style="color: var(--accent-not-mine);">${formatMoney(balances.notMineBalance, balances.symbol)}</span>
      </div>
    `;
  }
}

// 4. Settings View Renderer
function renderSettingsView() {
  const container = document.getElementById('settings-currency-list');
  if (container) {
    container.innerHTML = window.state.currencies.map(c => `
      <div class="curr-item">
        <div class="curr-item-left">
          <span class="curr-badge">${c.symbol}</span>
          <div>
            <div class="curr-title">${c.name} (${c.code})</div>
          </div>
        </div>
        <div>
          ${c.code === window.state.activeCurrency ? '<span class="count-badge" style="background:var(--accent-primary);color:#fff;">Active</span>' : ''}
        </div>
      </div>
    `).join('');
  }

  updateConverterDropdowns();
  updateConverterView();
}

// Live Exchange Rate Cache & Fetcher
const ratesCache = {};

async function fetchLiveExchangeRates(baseCurrency) {
  const errorNotice = document.getElementById('converter-error-notice');
  const resultBox = document.getElementById('converter-result-box');

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    const response = await fetch(`https://open.er-api.com/v6/latest/${baseCurrency}`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (!response.ok) throw new Error('Network response not ok');
    const data = await response.json();

    if (data && data.result === 'success' && data.rates) {
      ratesCache[baseCurrency] = {
        rates: data.rates,
        lastUpdate: data.time_last_update_utc || new Date().toUTCString()
      };
      if (errorNotice) errorNotice.classList.add('hidden');
      if (resultBox) resultBox.classList.remove('hidden');
      return ratesCache[baseCurrency];
    } else {
      throw new Error('API returned invalid format');
    }
  } catch (err) {
    console.warn('Live currency rate fetch failed:', err);
    if (errorNotice) errorNotice.classList.remove('hidden');
    if (!ratesCache[baseCurrency] && resultBox) {
      resultBox.classList.add('hidden');
    }
    return ratesCache[baseCurrency] || null;
  }
}

async function updateConverterView() {
  const fromSelect = document.getElementById('converter-from-select');
  const toSelect = document.getElementById('converter-to-select');
  const amountInput = document.getElementById('converter-amount-input');
  const rateBadge = document.getElementById('converter-rate-badge');
  const resultDisplay = document.getElementById('converter-result-display');
  const timestampEl = document.getElementById('converter-timestamp');

  if (!fromSelect || !toSelect || !amountInput) return;

  const fromCode = fromSelect.value || 'USD';
  const toCode = toSelect.value || 'EGP';
  const amount = parseFloat(amountInput.value) || 1;

  let cached = ratesCache[fromCode];
  if (!cached) {
    if (timestampEl) timestampEl.textContent = t('loadingRates');
    cached = await fetchLiveExchangeRates(fromCode);
  }

  if (cached && cached.rates && cached.rates[toCode] !== undefined) {
    const rate = cached.rates[toCode];
    const converted = amount * rate;
    const toSymbol = window.state.getCurrencySymbol(toCode);

    if (rateBadge) rateBadge.textContent = `1 ${fromCode} = ${rate.toLocaleString('en-US', { maximumFractionDigits: 4 })} ${toCode}`;
    if (resultDisplay) resultDisplay.textContent = `${formatMoney(converted, toSymbol)} (${toCode})`;
    if (timestampEl) timestampEl.textContent = `${t('lastUpdatedLabel')}: ${cached.lastUpdate.split(' 00:')[0]}`;
  }
}

function updateConverterDropdowns() {
  const currencies = window.state.currencies;
  const optionsHtml = currencies.map(c => `<option value="${c.code}">${c.code} (${c.symbol}) - ${c.name}</option>`).join('');

  const fromSelect = document.getElementById('converter-from-select');
  const toSelect = document.getElementById('converter-to-select');

  if (fromSelect) {
    const currFrom = fromSelect.value || 'USD';
    fromSelect.innerHTML = optionsHtml;
    fromSelect.value = currencies.some(c => c.code === currFrom) ? currFrom : 'USD';
  }
  if (toSelect) {
    const currTo = toSelect.value || 'EGP';
    toSelect.innerHTML = optionsHtml;
    toSelect.value = currencies.some(c => c.code === currTo) ? currTo : 'EGP';
  }
}

// Modal Handlers
function openTransactionModal(type = 'in', existingTx = null) {
  updateCurrencyDropdowns();
  const form = document.getElementById('form-transaction');
  if (!form) return;

  form.reset();

  const titleEl = document.getElementById('modal-tx-title');
  const txIdEl = document.getElementById('tx-id');
  const amountEl = document.getElementById('tx-amount');
  const currEl = document.getElementById('tx-currency');
  const beneficiaryEl = document.getElementById('tx-beneficiary');
  const dateEl = document.getElementById('tx-date');
  const catEl = document.getElementById('tx-category');
  const noteEl = document.getElementById('tx-note');

  let currentType = type;
  let currentAllocation = 'mine';

  if (existingTx) {
    titleEl.textContent = t('editTransaction');
    txIdEl.value = existingTx.id;
    amountEl.value = existingTx.amount;
    currEl.value = existingTx.currency;
    currentType = existingTx.type;
    currentAllocation = existingTx.allocation;
    beneficiaryEl.value = existingTx.beneficiary || '';
    dateEl.value = existingTx.date;
    catEl.value = existingTx.category || 'General';
    noteEl.value = existingTx.note || '';
  } else {
    titleEl.textContent = t('newTransaction');
    txIdEl.value = '';
    currEl.value = window.state.activeCurrency;
    dateEl.value = new Date().toISOString().split('T')[0];
  }

  // Update Movement Type Segment
  document.querySelectorAll('.type-segmented .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.type === currentType);
  });

  // Update Allocation Segment
  document.querySelectorAll('.allocation-segmented .segment-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.allocation === currentAllocation);
  });

  // Toggle Beneficiary input visibility
  const groupBeneficiary = document.getElementById('group-beneficiary');
  if (groupBeneficiary) {
    if (currentAllocation === 'not_mine') {
      groupBeneficiary.style.display = 'block';
    } else {
      groupBeneficiary.style.display = 'none';
    }
  }

  // Symbol Addon
  const symAddon = document.getElementById('tx-currency-symbol');
  if (symAddon) symAddon.textContent = window.state.getCurrencySymbol(currEl.value);

  document.getElementById('modal-transaction').classList.remove('hidden');
  setTimeout(() => amountEl.focus(), 150);
}

function closeTransactionModal() {
  document.getElementById('modal-transaction').classList.add('hidden');
}

function openDeleteModal(tx) {
  const preview = document.getElementById('delete-tx-preview');
  if (preview) {
    preview.innerHTML = renderTransactionCardHtml(tx);
  }
  document.getElementById('confirm-delete-btn').dataset.id = tx.id;
  document.getElementById('modal-delete-confirm').classList.remove('hidden');
}

function closeDeleteModal() {
  document.getElementById('modal-delete-confirm').classList.add('hidden');
}

// Master Render Refresh
function refreshAllViews() {
  renderDashboard();
  renderHistory();
  renderStatsView();
  renderSettingsView();
}
